"""Tests for CipherGenius"""
